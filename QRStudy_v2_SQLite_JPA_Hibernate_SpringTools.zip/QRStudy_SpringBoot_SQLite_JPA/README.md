# QRStudy — Versao 2 (SQLite + Spring Data JPA + Hibernate)

**Esta e uma segunda versao independente. O ZIP original nao foi modificado.**

Criado a partir do modulo real de cadastro de alunos do QRStudy. O frontend HTML/CSS/JavaScript foi preservado e o backend foi reorganizado para acompanhar o tutorial da professora (Model -> Controller -> Service -> Repository).

## Requisitos
- **JDK 17 ou superior** (a linguagem do projeto esta definida como Java 17; JDK 21 tambem serve)
- **Spring Tools for Eclipse** com suporte ao Maven; acesso a internet na primeira importacao para baixar as dependencias
- Nenhuma instalacao separada de servidor de banco: SQLite e incorporado via dependencia Maven

## Importar no Spring Tools (Windows)
1. Extraia este ZIP usando **Extrair tudo**.
2. Abra o Spring Tools e escolha **File > Import... > Maven > Existing Maven Projects**.
3. Clique em **Browse** e selecione a pasta **QRStudy_SpringBoot_SQLite_JPA** (a que tem o arquivo `pom.xml`).
4. Marque o projeto `qrstudy-sqlite-jpa` e clique **Finish**.
5. Se aparecer erro de biblioteca, espere o Maven terminar ou clique no projeto com o botao direito > **Maven > Update Project**.
6. Abra `src/main/java/br/edu/qrstudy/Aplicacao.java` > botao direito > **Run As > Spring Boot App**.
7. Aguarde a mensagem `Started Aplicacao`. Nao precisa instalar SQLite separadamente.

## Enderecos
- Interface HTML: **http://localhost:8081/**
- Swagger UI: **http://localhost:8081/swagger-ui/index.html**
- Lista JSON: **http://localhost:8081/api/alunos**
- OpenAPI: **http://localhost:8081/v3/api-docs**

A porta **8081** foi escolhida para nao conflitar com o QRStudy original (8080). O JavaScript usa URLs relativas e funciona sem alteracoes em 8081.

## Banco de dados (importante)
- Nesta versao: `jdbc:sqlite:qrstudy-sqlite.db` (`application.properties`). O SQLite cria esse arquivo na **pasta de execucao** da aplicacao (normalmente a pasta do projeto no Spring Tools).
- O Hibernate cria e atualiza a estrutura da tabela `aluno` via `spring.jpa.hibernate.ddl-auto=update`.
- O banco **H2 anterior NAO e convertido ou importado automaticamente**: esta nova versao inicia com cadastros proprios, e o projeto original continua intacto.
- A chave primaria `id` e gerada automaticamente.
- A combinacao `escola + matricula` e unica. Uma matricula repetida na mesma escola retorna HTTP 409.
- O SQLite e o H2 nao exigem servidor de banco separado, mas esta versao usa **JPA/Hibernate**, nao JDBC direto.
- A opcao `ddl-auto=update` e adequada para a demonstracao academica; para sistemas em producao, prefira migracoes versionadas.

## Cinco endpoints obrigatorios

| Metodo | Endpoint | Resultado esperado |
|---|---|---|
| POST | `/api/alunos` | 201 + aluno cadastrado + `Location` |
| GET | `/api/alunos` | 200 + lista de alunos |
| GET | `/api/alunos/{id}` | 200, ou 404 quando nao existir |
| PUT | `/api/alunos/{id}` | 200, ou 404 quando nao existir |
| DELETE | `/api/alunos/{id}` | 204, ou 404 quando nao existir |

Erros de dados invalidos: 400; matricula duplicada na mesma escola: 409.

### Exemplo POST (Request body)

```json
{
  "escola": 101,
  "nome": "Maria Oliveira",
  "nascimento": "2010-05-10",
  "matricula": "2026001",
  "serie": "9º ano",
  "turma": "A",
  "turno": "MANHA",
  "status": "ATIVO"
}
```

O corpo da resposta mantem o formato do QRStudy original:

```json
{
  "id": 1,
  "dados": {
    "escola": 101,
    "nome": "Maria Oliveira",
    "nascimento": "2010-05-10",
    "matricula": "2026001",
    "serie": "9º ano",
    "turma": "A",
    "turno": "MANHA",
    "status": "ATIVO"
  }
}
```

## Estrutura: para que serve cada classe?
- `Aplicacao.java`: inicializa o Spring Boot e define os metadados OpenAPI.
- `model/Aluno.java`: a entidade JPA (`@Entity`, `@Id`), correspondente a tabela do SQLite.
- `dto/DadosAluno.java`: DTO com validacoes, recebe JSON do POST/PUT.
- `dto/AlunoResposta.java`: DTO que preserva o formato JSON `id + dados` esperado pelo `app.js` original.
- `repository/AlunoRepository.java`: interface `JpaRepository`, permite salvar, consultar e excluir.
- `service/AlunoService.java`: regras, busca por ID, matricula unica, chamadas ao Repository e transacoes.
- `controller/AlunoController.java`: endpoints HTTP e documentacao Swagger.
- `controller/ApiExceptionHandler.java`: respostas 400 e 409 para dados invalidos/duplicados.
- `static/index.html`: formularios, lista e botoes.
- `static/app.js`: `fetch` com POST/GET/PUT/DELETE; igual a versao original.
- `static/estilo.css`: aparencia visual; igual a versao original.
- `src/test/java/.../AlunoApiTest.java`: testes automatizados de CRUD, erros, HTML e Swagger usando **outro arquivo SQLite temporario**.

## Executar testes
No terminal com Maven instalado e dependencias acessiveis:

```bash
mvn clean test
```

No Spring Tools, clique com o botao direito no projeto > **Run As > Maven test**.

**Status da validacao desta entrega**: arquivos Java, XML, scripts e integracao estatica foram conferidos. Nao foi possivel executar `mvn test` aqui (Maven indisponivel e acesso a repositorios Maven bloqueado). Antes de apresentar, importe e confirme o ciclo CRUD e o Swagger na sua maquina.

## Se der erro
- **Porta ocupada?** Verifique se esta testando `localhost:8081`; se necessario, altere `server.port` no `application.properties` e reinicie.
- **Dependencias vermelhas?** Atualize o Maven do projeto; confirme que o computador tem acesso a internet para o primeiro download.
- **Banco antigo?** O arquivo usado se chama `qrstudy-sqlite.db`, nao `qrstudy` do H2. Nao remova o banco antigo.
- **Erros no primeiro boot?** Abra o Console e envie a mensagem completa antes de alterar a configuracao do Hibernate.
- **Dados nao aparecem?** Confira no Console o diretorio de execucao e a URL JDBC; como o nome do banco e relativo, executar fora da pasta do projeto pode criar outro arquivo SQLite.
