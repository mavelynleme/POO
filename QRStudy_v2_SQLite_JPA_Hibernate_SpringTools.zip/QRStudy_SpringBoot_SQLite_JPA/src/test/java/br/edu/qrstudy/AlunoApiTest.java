package br.edu.qrstudy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AlunoApiTest {
    @Autowired MockMvc http;
    private static final String BASE = "/api/alunos";

    // O teste escreve em seu proprio arquivo SQLite, sem modificar os registros do aluno.
    private static final Path BANCO_TESTE = criarBancoTemporario();

    @DynamicPropertySource
    static void configurarBanco(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", () -> "jdbc:sqlite:" + BANCO_TESTE.toAbsolutePath());
        registry.add("spring.jpa.hibernate.ddl-auto", () -> "create");
    }

    private static Path criarBancoTemporario() {
        try {
            Path banco = Files.createTempFile("qrstudy-jpa-teste-", ".db");
            banco.toFile().deleteOnExit();
            return banco;
        } catch (IOException ex) {
            throw new IllegalStateException("Nao foi possivel criar banco temporario dos testes", ex);
        }
    }

    private static final String DADOS = """
        {"escola":101,"nome":"Ana Exemplo","nascimento":"2015-04-10",
         "matricula":"TESTE-2026","serie":"5º ano","turma":"B","turno":"MANHA","status":"ATIVO"}
        """;

    @Test
    void crudComValidacoes() throws Exception {
        var criado = http.perform(post(BASE).contentType("application/json").content(DADOS))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").isNumber())
            .andExpect(jsonPath("$.dados.nome").value("Ana Exemplo"))
            .andReturn();
        String url = criado.getResponse().getHeader("Location");

        http.perform(get(BASE)).andExpect(status().isOk()).andExpect(jsonPath("$[0].dados.matricula").value("TESTE-2026"));
        http.perform(get(url)).andExpect(status().isOk()).andExpect(jsonPath("$.dados.turma").value("B"));
        http.perform(post(BASE).contentType("application/json").content(DADOS))
            .andExpect(status().isConflict());

        http.perform(put(url).contentType("application/json").content(DADOS.replace("\"turma\":\"B\"", "\"turma\":\"C\"")))
            .andExpect(status().isOk()).andExpect(jsonPath("$.dados.turma").value("C"));
        http.perform(get(url)).andExpect(jsonPath("$.dados.turma").value("C"));

        http.perform(delete(url)).andExpect(status().isNoContent());
        http.perform(get(url)).andExpect(status().isNotFound());
        http.perform(delete(url)).andExpect(status().isNotFound());
        http.perform(put(url).contentType("application/json").content(DADOS)).andExpect(status().isNotFound());
        http.perform(post(BASE).contentType("application/json").content("{}"))
            .andExpect(status().isBadRequest());
        http.perform(get(BASE + "/0")).andExpect(status().isBadRequest());
    }

    @Test
    void interfaceESwaggerEstaoDisponiveis() throws Exception {
        http.perform(get("/index.html")).andExpect(status().isOk());
        http.perform(get("/app.js")).andExpect(status().isOk());
        http.perform(get("/v3/api-docs")).andExpect(status().isOk())
            .andExpect(jsonPath("$.info.version").value("2.0"))
            .andExpect(jsonPath("$.paths['/api/alunos'].post.responses['201']").exists())
            .andExpect(jsonPath("$.paths['/api/alunos/{id}'].delete.responses['404']").exists());
    }
}
