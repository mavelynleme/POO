package br.edu.qrstudy.controller;

import br.edu.qrstudy.dto.AlunoResposta;
import br.edu.qrstudy.dto.DadosAluno;
import br.edu.qrstudy.service.AlunoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Recebe HTTP e delega as regras ao AlunoService. */
@RestController
@RequestMapping("/api/alunos")
@Tag(name = "Alunos", description = "CRUD de alunos com SQLite, JPA e Hibernate")
public class AlunoController {
    private final AlunoService service;

    public AlunoController(AlunoService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Cadastrar aluno", description = "Recebe um JSON, valida, grava no SQLite e gera o ID do aluno.")
    @ApiResponse(responseCode = "201", description = "Aluno cadastrado", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "Dados invalidos", content = @Content)
    @ApiResponse(responseCode = "409", description = "Matricula repetida na mesma escola", content = @Content)
    public ResponseEntity<AlunoResposta> cadastrar(@Valid @RequestBody DadosAluno dados) {
        AlunoResposta aluno = service.cadastrar(dados);
        return ResponseEntity.created(URI.create("/api/alunos/" + aluno.id())).body(aluno);
    }

    @GetMapping
    @Operation(summary = "Listar alunos", description = "Retorna todos os alunos, ordenados por nome e ID.")
    @ApiResponse(responseCode = "200", description = "Lista retornada (pode estar vazia)", useReturnTypeSchema = true)
    public List<AlunoResposta> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Consultar aluno", description = "Localiza um aluno pelo ID gerado no cadastro.")
    @ApiResponse(responseCode = "200", description = "Aluno encontrado", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "ID invalido", content = @Content)
    @ApiResponse(responseCode = "404", description = "Aluno nao encontrado", content = @Content)
    public AlunoResposta consultar(@Parameter(description = "ID numerico do aluno", example = "1")
                                 @PathVariable Long id) {
        return service.consultar(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar aluno", description = "Substitui os dados de um cadastro existente preservando seu ID.")
    @ApiResponse(responseCode = "200", description = "Cadastro atualizado", useReturnTypeSchema = true)
    @ApiResponse(responseCode = "400", description = "Dados ou ID invalidos", content = @Content)
    @ApiResponse(responseCode = "404", description = "Aluno nao encontrado", content = @Content)
    @ApiResponse(responseCode = "409", description = "Matricula repetida na mesma escola", content = @Content)
    public AlunoResposta atualizar(@Parameter(description = "ID numerico do aluno", example = "1")
                                  @PathVariable Long id, @Valid @RequestBody DadosAluno dados) {
        return service.atualizar(id, dados);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Excluir aluno", description = "Apaga o registro pelo ID.")
    @ApiResponse(responseCode = "204", description = "Aluno excluido", content = @Content)
    @ApiResponse(responseCode = "400", description = "ID invalido", content = @Content)
    @ApiResponse(responseCode = "404", description = "Aluno nao encontrado", content = @Content)
    public ResponseEntity<Void> excluir(@Parameter(description = "ID numerico do aluno", example = "1")
                                        @PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
