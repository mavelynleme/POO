package br.edu.qrstudy.model;

import br.edu.qrstudy.dto.DadosAluno;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDate;

/** Entidade: cada objeto Aluno corresponde a uma linha da tabela aluno. */
@Entity
@Table(name = "aluno", uniqueConstraints =
    @UniqueConstraint(name = "uk_aluno_escola_matricula", columnNames = {"escola", "matricula"}))
public class Aluno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long escola;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(nullable = false)
    private LocalDate nascimento;

    @Column(nullable = false, length = 30)
    private String matricula;

    @Column(nullable = false, length = 30)
    private String serie;

    @Column(nullable = false, length = 30)
    private String turma;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DadosAluno.Turno turno;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DadosAluno.Status status;

    protected Aluno() { } // Obrigatorio para o JPA/Hibernate.

    public Aluno(DadosAluno dados) {
        atualizarDados(dados);
    }

    public void atualizarDados(DadosAluno dados) {
        this.escola = dados.escola();
        this.nome = dados.nome();
        this.nascimento = dados.nascimento();
        this.matricula = dados.matricula();
        this.serie = dados.serie();
        this.turma = dados.turma();
        this.turno = dados.turno();
        this.status = dados.status();
    }

    public Long getId() { return id; }
    public Long getEscola() { return escola; }
    public String getNome() { return nome; }
    public LocalDate getNascimento() { return nascimento; }
    public String getMatricula() { return matricula; }
    public String getSerie() { return serie; }
    public String getTurma() { return turma; }
    public DadosAluno.Turno getTurno() { return turno; }
    public DadosAluno.Status getStatus() { return status; }
}
