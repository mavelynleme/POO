package br.edu.qrstudy.service;

import br.edu.qrstudy.dto.AlunoResposta;
import br.edu.qrstudy.dto.DadosAluno;
import br.edu.qrstudy.model.Aluno;
import br.edu.qrstudy.repository.AlunoRepository;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Camada que aplica regras e chama o Repository, conforme a estrutura ensinada em aula. */
@Service
@Transactional(readOnly = true)
public class AlunoService {
    private final AlunoRepository repository;

    public AlunoService(AlunoRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public AlunoResposta cadastrar(DadosAluno dados) {
        if (repository.existsByEscolaAndMatricula(dados.escola(), dados.matricula())) {
            throw duplicada();
        }
        // saveAndFlush confirma a gravacao e permite obter o ID antes da resposta.
        return AlunoResposta.de(repository.saveAndFlush(new Aluno(dados)));
    }

    public List<AlunoResposta> listar() {
        return repository.findAllByOrderByNomeAscIdAsc()
            .stream().map(AlunoResposta::de).toList();
    }

    public AlunoResposta consultar(Long id) {
        return AlunoResposta.de(encontrar(id));
    }

    @Transactional
    public AlunoResposta atualizar(Long id, DadosAluno dados) {
        Aluno aluno = encontrar(id);
        if (repository.existsByEscolaAndMatriculaAndIdNot(dados.escola(), dados.matricula(), id)) {
            throw duplicada();
        }
        aluno.atualizarDados(dados);
        return AlunoResposta.de(repository.saveAndFlush(aluno));
    }

    @Transactional
    public void excluir(Long id) {
        Aluno aluno = encontrar(id);
        repository.delete(aluno);
        repository.flush();
    }

    private Aluno encontrar(Long id) {
        if (id == null || id <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "O ID deve ser um numero positivo.");
        }
        return repository.findById(id).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno nao encontrado."));
    }

    private static ResponseStatusException duplicada() {
        return new ResponseStatusException(HttpStatus.CONFLICT,
            "Esta matricula ja existe nesta escola.");
    }
}
