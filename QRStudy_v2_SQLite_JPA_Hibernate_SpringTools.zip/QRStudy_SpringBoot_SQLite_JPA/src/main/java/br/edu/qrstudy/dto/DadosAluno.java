package br.edu.qrstudy.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

/** DTO: dados aceitos no POST e no PUT; mantem o JSON da versao original. */
public record DadosAluno(
    @NotNull @Positive Long escola,
    @NotBlank @Size(max = 150) String nome,
    @NotNull @PastOrPresent LocalDate nascimento,
    @NotBlank @Size(max = 30) String matricula,
    @NotBlank @Size(max = 30) String serie,
    @NotBlank @Size(max = 30) String turma,
    @NotNull Turno turno,
    @NotNull Status status
) {
    public enum Turno { MANHA, TARDE, NOITE, INTEGRAL }
    public enum Status { ATIVO, INATIVO, TRANSFERIDO, FORMADO }

    public DadosAluno {
        nome = limpar(nome);
        matricula = limpar(matricula);
        serie = limpar(serie);
        turma = limpar(turma);
    }

    private static String limpar(String valor) {
        return valor == null ? null : valor.strip();
    }
}
