package br.edu.qrstudy;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(
    title = "QRStudy | Cadastro de alunos (SQLite + JPA)",
    version = "2.0",
    description = "Segunda versao academica do modulo de cadastro de alunos. CRUD RESTful com Controller, Service, Repository, JPA/Hibernate, SQLite e interface HTML."
))
public class Aplicacao {
    public static void main(String[] args) {
        SpringApplication.run(Aplicacao.class, args);
    }
}
