package br.edu.qrstudy.repository;

import br.edu.qrstudy.model.Aluno;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** JpaRepository ja oferece save, findById, findAll e delete. */
@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long> {
    List<Aluno> findAllByOrderByNomeAscIdAsc();
    boolean existsByEscolaAndMatricula(Long escola, String matricula);
    boolean existsByEscolaAndMatriculaAndIdNot(Long escola, String matricula, Long id);
}
