package br.edu.qrstudy.dto;

import br.edu.qrstudy.model.Aluno;

/** Preserva o contrato JSON original: {"id": 1, "dados": {...}}. */
public record AlunoResposta(Long id, DadosAluno dados) {
    public static AlunoResposta de(Aluno aluno) {
        return new AlunoResposta(aluno.getId(), new DadosAluno(
            aluno.getEscola(), aluno.getNome(), aluno.getNascimento(),
            aluno.getMatricula(), aluno.getSerie(), aluno.getTurma(),
            aluno.getTurno(), aluno.getStatus()
        ));
    }
}
