# Passo a passo para testar e apresentar o QRStudy SQLite

Esta versao usa **porta 8081**. Nao confunda com o projeto original H2 (8080).

1. Abra `http://localhost:8081/`. Cadastre Maria Oliveira: escola 101, matricula 2026001, nascimento 10/05/2010, 9º ano, turma A, MANHA, ATIVO. Espere "Cadastro salvo. ID do aluno: ...".
2. Abra `http://localhost:8081/swagger-ui/index.html`. Faca `GET /api/alunos`. Espere HTTP 200 e lista com Maria.
3. Faca `GET /api/alunos/{id}` com o ID realmente gerado. Espere 200 e os dados do cadastro.
4. Faca `PUT /api/alunos/{id}` com o JSON do README alterando turma para B. Espere 200. Confira o novo valor com GET.
5. Na interface HTML, use **Editar**, altere a turma novamente e salve. Confira com GET.
6. Pare o Spring Boot, inicie novamente e clique em **Ver todos**. O registro deve continuar no SQLite, pois esta em arquivo.
7. Faca POST com a mesma escola e matricula para testar o conflito. Espere 409.
8. Exclua o registro pelo botao **Excluir** do HTML (confirme na janela). Espere a lista vazia.
9. Consulte o mesmo ID no Swagger. Espere **404 Not Found**.
10. Demonstre diretamente no Swagger o `DELETE /api/alunos/{id}` com **outro** registro ficticio, se desejar evidenciar tambem o codigo 204.

**Explicacao oral**: "Quando clico Cadastrar no HTML, o JavaScript usa fetch POST. O AlunoController recebe o JSON, chama o AlunoService, que aplica as regras e usa AlunoRepository. O JPA/Hibernate faz a persistencia no SQLite. A API retorna o ID e o HTML atualiza a lista." 

**Atencao**: nao inclua `id` no corpo do POST ou PUT: o id e gerado pelo banco e passado pela URL no PUT/DELETE/GET por ID.
