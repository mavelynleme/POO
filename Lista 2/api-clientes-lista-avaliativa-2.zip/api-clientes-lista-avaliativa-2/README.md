# 2ª Lista Avaliativa — API RESTful de Clientes

Projeto Maven com Java 17, Spring Boot 3.2.12, Spring Data JPA, SQLite e Swagger/OpenAPI (springdoc 2.5.0). A combinação de versões é voltada à compatibilidade com o tutorial acadêmico, **não a uma implantação de produção**.

## Como importar no Spring Tools for Eclipse
1. File > Import > Maven > Existing Maven Projects.
2. Selecione a pasta `api-clientes-lista-avaliativa-2` (contém `pom.xml`).
3. Aguarde o download das dependências Maven (requer internet).
4. Confira o Java 17 ou superior compatível com o projeto.
5. Execute `ClientesApiApplication.java` com Run As > Spring Boot App.
6. Abra http://localhost:8080/swagger-ui.html (ou http://localhost:8080/swagger-ui/index.html).

## Estrutura
- `model/Cliente.java`: entidade JPA, atributos, construtores, getters/setters e validações.
- `repository/ClienteRepository.java`: interface JpaRepository para acesso ao SQLite.
- `service/ClienteService.java`: regras CRUD e tratamento de cliente inexistente.
- `controller/ClienteController.java`: cinco endpoints e anotações Swagger.
- `controller/ValidacaoExceptionHandler.java`: respostas de validação HTTP 400.
- `application.properties`: configurações do banco.
- `exemplos/`: cinco JSONs de cadastro e um de atualização.

## Endpoints
| Método | URL | Retorno esperado |
|---|---|---|
| POST | http://localhost:8080/clientes | 201 Created |
| GET | http://localhost:8080/clientes | 200 OK |
| GET | http://localhost:8080/clientes/1 | 200 OK ou 404 |
| PUT | http://localhost:8080/clientes/1 | 200 OK ou 404 |
| DELETE | http://localhost:8080/clientes/1 | 204 No Content ou 404 |

## Sequência de testes exigida
1. Execute cinco POSTs usando os arquivos `exemplos/post-cliente-1.json` até `post-cliente-5.json` (Content-Type: application/json).
2. Faça GET `/clientes` para listar todos.
3. Faça GET `/clientes/1` para buscar pelo ID (use o ID efetivamente retornado pelo POST).
4. Faça PUT `/clientes/1` usando `exemplos/put-cliente-1.json`.
5. Faça DELETE `/clientes/1` e confirme com GET que retorna 404.

**Atenção:** os CNPJs dos exemplos são fictícios para demonstração, não devem ser considerados cadastros reais. O banco `meu_banco_de_dados.db` é criado na pasta de execução. Os IDs podem variar caso já existam registros. O banco não acompanha o ZIP, pois deve ser gerado pela aplicação.

## Observações
- O código não foi executado neste ambiente por indisponibilidade do Maven e de resolução das dependências. É necessário validar a inicialização e os cinco testes no Spring Tools.
- O Springdoc 2.5.0 é a versão solicitada pela atividade; por isso foi usada uma versão Spring Boot 3.2.x compatível com essa geração do Springdoc.
- Para uso real, atualizar dependências e adicionar autenticação, migrações de banco, testes automatizados e regras específicas de CNPJ.
