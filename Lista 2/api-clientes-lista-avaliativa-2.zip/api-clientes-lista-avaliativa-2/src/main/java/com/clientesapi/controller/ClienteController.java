package com.clientesapi.controller;

import com.clientesapi.model.Cliente;
import com.clientesapi.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/clientes")
@Tag(name = "Clientes", description = "Operações CRUD para cadastro e gerenciamento de clientes")
public class ClienteController {
    private final ClienteService service;

    public ClienteController(ClienteService service) {
        this.service = service;
    }

    @Operation(summary = "Cadastra um novo cliente", description = "Recebe os dados do cliente em JSON, valida os campos e salva no SQLite. O ID é gerado automaticamente.")
    @ApiResponse(responseCode = "201", description = "Cliente criado com sucesso")
    @ApiResponse(responseCode = "400", description = "Dados inválidos")
    @PostMapping
    public ResponseEntity<Cliente> cadastrar(@Valid @RequestBody Cliente cliente) {
        Cliente salvo = service.salvar(cliente);
        return ResponseEntity.created(URI.create("/clientes/" + salvo.getId())).body(salvo);
    }

    @Operation(summary = "Lista todos os clientes", description = "Retorna todos os clientes cadastrados em formato JSON; lista vazia quando não houver registros.")
    @ApiResponse(responseCode = "200", description = "Consulta realizada")
    @GetMapping
    public List<Cliente> listarTodos() {
        return service.listarTodos();
    }

    @Operation(summary = "Busca um cliente pelo ID", description = "Consulta um cliente específico pelo identificador numérico.")
    @ApiResponse(responseCode = "200", description = "Cliente encontrado")
    @ApiResponse(responseCode = "404", description = "Cliente não encontrado")
    @GetMapping("/{id}")
    public Cliente buscarPorId(@Parameter(description = "ID do cliente", example = "1") @PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @Operation(summary = "Atualiza um cliente pelo ID", description = "Substitui os dados cadastrais do cliente indicado pelo ID, mantendo o mesmo identificador.")
    @ApiResponse(responseCode = "200", description = "Cliente atualizado")
    @ApiResponse(responseCode = "400", description = "Dados inválidos")
    @ApiResponse(responseCode = "404", description = "Cliente não encontrado")
    @PutMapping("/{id}")
    public Cliente atualizar(@Parameter(description = "ID do cliente", example = "1") @PathVariable Long id, @Valid @RequestBody Cliente cliente) {
        return service.atualizar(id, cliente);
    }

    @Operation(summary = "Exclui um cliente pelo ID", description = "Remove permanentemente o cliente identificado pelo ID.")
    @ApiResponse(responseCode = "204", description = "Cliente excluído")
    @ApiResponse(responseCode = "404", description = "Cliente não encontrado")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletar(@Parameter(description = "ID do cliente", example = "1") @PathVariable Long id) {
        service.deletar(id);
    }
}
