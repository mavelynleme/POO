package com.clientesapi;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@OpenAPIDefinition(info = @Info(title = "API de Clientes", version = "1.0", description = "CRUD de clientes com Spring Boot, Spring Data JPA e SQLite. Segunda Lista Avaliativa."))
@SpringBootApplication
public class ClientesApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClientesApiApplication.class, args);
    }
}
