package com.clientesapi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class ValidacaoExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> tratarValidacao(MethodArgumentNotValidException exception) {
        Map<String, String> campos = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(erro ->
            campos.put(erro.getField(), erro.getDefaultMessage()));
        Map<String, Object> resposta = new LinkedHashMap<>();
        resposta.put("erro", "Dados inválidos");
        resposta.put("campos", campos);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
    }
}
